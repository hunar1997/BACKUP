#! /usr/bin/bash 

#---------Variables----------
MPI_PROCESSES=2
MPI="mpirun -np $MPI_PROCESSES"
QE_BINS_PATH="/usr/bin"

# binary locations
PW="$MPI $QE_BINS_PATH/pw.x"
BANDS="$MPI $QE_BINS_PATH/bands.x"
DOS="$MPI $QE_BINS_PATH/dos.x"
PP="$MPI $QE_BINS_PATH/pp.x"
GNUPLOT="/usr/bin/gnuplot"
# --------------------------

echo "Running SCF calculation..."
$PW < graphene.scf.in > graphene.scf.out

echo "Running NSCF for BANDS calculation..."
$PW < graphene.nscf_band.in > graphene.nscf_band.out

echo "Running BANDS calculation..."
$BANDS < graphene.band.in > graphene.band.out

echo "Plotting BANDS results..."
$GNUPLOT band.plt -persist

echo "Running NSCF for DOS calculation..."
$PW < graphene.nscf.in > graphene.nscf.out

echo "Running DOS calculation..."
$DOS < graphene.dos.in > graphene.dos.out

echo "Plotting DOS results..."
$GNUPLOT dos.plt  -persist

echo "Running charge density calculation..."
$PP < graphene.pp.in > graphene.pp.out

echo "Plotting charge density results..."
$GNUPLOT charge.plt  -persist
